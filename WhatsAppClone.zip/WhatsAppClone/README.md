WhatsAppClone 
# WhatsApp_Android_Clone 
 
▷ Create an android app like whatsApp 
 
▷ Full Video Tutorial Playlist here: https://www.youtube.com/watch?v=wdcH58Nzm-o&index=1&list=PLxabZQCAe5fgGQggJxp5nuI1ESzP-oMED <br /> 
 
▷ Become a Patreon: https://www.patreon.com/simpleCoder<br /> 
▷ Donate with PayPal: https://www.paypal.me/simcoder<br /> 
▷ Twitter: https://twitter.com/S1mpleCoder<br /> 
▷ GitHub : https://goo.gl/88FHk4<br /> 
 
▷ If you have any question please ask, I'll try to answer to every question and even look at your code if that is necessary. 
 
 
**Important Links** 
 
Firebase: https://goo.gl/9Wahb1<br /> 
Glide: https://github.com/bumptech/glide<br /> 
 
P.S: If ou're going to download the full project please use your own firebase API, the one in the project will NOT be mantained and the app may not work. 
 
 
# Implementation Guide<br /> 
**1 - Project**<br /> 
1 - Open the Project in your android studio;<br /> 
2 - !!!!IMPORTANT!!!! Change the Package Name. You can check how to do that here (https://stackoverflow.com/questions/16804093/android-studio-rename-package)<br /> 
 
 
**2 - Firebase Panel**<br /> 
1 - Create Firebase Project (https://console.firebase.google.com/);<br /> 
2 - import the file google-service.json into your project as the instructions say;<br /> 
3 - Change Pay Plan to either Flame or Blaze; !optional<br /> 
4 - Go to Firebase -> Registration and activate Login/Registrtion with Phone Number<br /> 
5 - Go to Firebase -> storage and activate it;<br /> 
